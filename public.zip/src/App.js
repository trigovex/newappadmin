import logo from './logo.svg';
import './App.css';
import AdminNavigation from './Admin/AdminNavigation';
 
function App() {
  return (
    <div className="App">
       <h1>hiii</h1>
    </div>
  );
}

export default App