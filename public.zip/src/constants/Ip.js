export const Ip = "https://vast-ruby-duck-wrap.cyclic.app";



//https://sore-ruby-scarab-boot.cyclic.app
// "https://myhomedel.herokuapp.com" 
//http://192.168.0.111:5000